import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Controlador {

    static String getUsuario() {

        Scanner scanner;
        scanner = new Scanner(System.in);
        String opcion;
        String usuario;
        System.out.println("\nMENU USUARIOS \n" +
                "-------------------------\n" +
                "(A) Usuarios Reales\n" +
                "(B) Buscar usuario por inicial\n");
        System.out.println("Ingrese su opcion: ");
        opcion = scanner.nextLine();

        while(!opcion.equals("A") && !opcion.equals("B")){
            System.out.println("Opcion ingresada no esta disponible!\nIngrese nuevamente la opcion:");
            opcion = scanner.nextLine();
        }

        if (opcion.equals("B")){
            System.out.println("Ingrese inicial del usuario que desea buscar:");
            usuario = scanner.nextLine();
            return opcion + " " + usuario;
        }
        else{
            return opcion + " ";
        }
    }

    static void getInicio() throws IOException {
        String archivo = "./bash/test.bash ";
        Process p = Runtime.getRuntime().exec( archivo);
        BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line = null;
        while ((line = in.readLine()) != null){
            System.out.println(line);
        }
    }

    static String getArchivo(){
        Scanner scanner = new Scanner(System.in);
        String archivo = " ", opcion = "";
        System.out.println("\nMENU INICIO\n " +
                "-------------------------------\n" +
                "(A) INFORMACION USUARIOS\n" +
                "(B) INFORMACION ARCHIVOS\n" +
                "(C) ACTIVIDADES USUARIOS\n" +
                "(D) SALIR\n" +
                "-------------------------------\n");
        opcion = scanner.nextLine();
        while (!opcion.equals("A") && !opcion.equals("B") && (!opcion.equals("C") && (!opcion.equals("D")))){
            System.out.println("OPCION INGRESADA NO CORRESPONDE");
            opcion = scanner.nextLine();
        }

        switch (opcion){
            case "A": archivo = "./bash/Usuarios.sh " + getUsuario(); break;
            case "B": archivo = "./bash/busqueda_archivos.sh " + menuArchivos()  ; break;
            case "C": archivo = "./bash/tercera_parte.sh " + menuActividad(); break;
            case "D": archivo = "./bash/Salir.sh "; break;
        }

        return archivo;
    }

    static String menuArchivos(){
        Scanner scanner;
        scanner = new Scanner(System.in);
        String opcion, direc;
        String archivo = " ";
        System.out.println("\nMENU ARCHIVOS\n" +
                "-------------------------\n" +
                "(A) Mostrar directorios\n" +
                "(B) Mostrar ficheros\n" +
                "(C) Mostrar ficheros de tamaño mayor a 1024 KB\n" +
                "(D) Buscar fichero o directorio\n" +
                "(E) Mostrar archivos que mas consumen CPU y memoria\n" +
                "---------------------------------------------------------\n");
        System.out.println("Ingrese su opcion: ");
        opcion = scanner.nextLine();

        while(!opcion.equals("A") && !opcion.equals("B") && !opcion.equals("C") && !opcion.equals("D")){
            System.out.println("Opcion ingresada no esta disponible!\nIngrese nuevamente la opcion:");
            opcion = scanner.nextLine();
        }
        if (opcion.equals("D")){
            System.out.println("Ingrese directorio que desea buscar:");
            direc = scanner.nextLine();
            return opcion + " " + direc;
        }
        else{
            return opcion + " ";
        }
    }
    static String menuActividad(){
        Scanner scanner;
        scanner = new Scanner(System.in);
        String opcion, direc;
        String archivo = " ";
        System.out.println("\nMENU ACTIVIDADES USUARIOS\n" +
                "-------------------------\n" +
                "(A) Archivos modificados en las ultimas 24 hrs. \n" +
                "(B) Conexiones en las ultimas 24 hrs. \n" +
                "(C) Ejecutar script periodicamente\n " +
                "--------------------------------------------------------");
        System.out.println("Ingrese su opcion: ");
        opcion = scanner.nextLine();

        while(!opcion.equals("A") && !opcion.equals("B") && !opcion.equals("C")){
            System.out.println("Opcion ingresada no esta disponible!\nIngrese nuevamente la opcion:");
            opcion = scanner.nextLine();
        }
        return opcion;
    }


}