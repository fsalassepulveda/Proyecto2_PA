import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class main {

    private static Process p;

    public  static void main(String[] args) throws IOException, InterruptedException {
        boolean v = true;

        Controlador.getInicio();
        //Contenedor.getArchivo();
        while(v) {
            try {
                //Process s = Runtime.getRuntime().exec("ls -llt");
                p = Runtime.getRuntime().exec(Controlador.getArchivo());
                String line = null;
                BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
                //!Contenedor.getArchivo().equals("./bash/Salir.sh")


                while (((line = in.readLine()) != null)) {
                    System.out.println(line);

                }
                Thread.sleep(2000);
                if(Controlador.getArchivo().equals("./bash/Salir.sh")){
                    v = false;
                }

            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
    }

}

