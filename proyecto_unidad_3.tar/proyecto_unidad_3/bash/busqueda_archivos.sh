#!/bin/bash


OPCION=$1
ARCHIVO=$2

echo -e "\n--------------------------------------------------------------------------"


if [ $OPCION == "A" ];then
    clear
    echo -e "DIRECTORIOS ENCONTRADOS: "
    ls -lhR $HOME| grep ^d | awk 'sum +=1 {print "-" $9} END{print "Total directorios: " sum }'
    echo -e "\n--------------------------------------------------------------------"

elif [ $OPCION == "B" ];then
    echo -e "\n FICHEROS ENCONTRADOS: "
    ls -lhR $HOME| grep ^d | awk 'sum +=1 {print "-" $9} END{print "Total ficheros: " sum }'
    echo -e "\n--------------------------------------------------------------------"

elif [ $OPCION == "C" ];then
    echo "La cantidad de archivos en HOME que presentan un peso mayor a 1024 mbyts corresponden a :"
    cd $HOME
    ls -lR | awk '$5 > 8192000 { print $9 " --- " $5 }'

elif [ $OPCION == "D" ];then
    clear
    echo "Ingrese el nombre del directorio o fichero que desea  buscar"
    cd $HOME
    val="$(find $HOME | grep "$2$")"
    echo "El elemento existe en esta ruta: "$val
    result="$(file $val)"
    echo "El fichero es de tipo: " $result

elif [ $OPCION == "E" ];then
    echo -e "PROCESOS QUE CONSUMEN MAS CPU: \n"
    ps -eo cmd,%cpu --sort=-%cpu | head -n4 | grep "^/"

    echo -e "PROCESOS QUE CONSUMEN MAS MEMORIA: \n"
    ps -eo cmd,%cpu --sort=-%mem | head -n4 | grep "^/"

fi


