#!/bin/bash
#INICIO
#Dia+hora
#Host (nombre de la maquina)
#Estado de la cpu + uso de memoria 
#Estado de los discos (espacio utilizado + disponible)
#Visualizar usuario que ejecuta y tiempo actual de login
#Mostrar cuantos archivos y Mb tiene el usuario en /home

clear
echo -e "BIENVENIDE $USER
-----------------------
`date +"%A %d/%m/%Y %H":"%M"`\n"

echo -e "INFORMACION DEL SISTEMA:
------------------------"
echo "Nombre de la maquina (Host): `uname -n` " 
echo "Sistema operativo: `uname -o`" 
echo "MEMORIA"
free --mega| grep "Memoria: " | awk '{print "- Espacio libre de la memoria: " $3 " MB"}'
free --mega | grep "Swap:" | awk '{print "- Espacio libre de la memoria virtual: " $3 " MB"}'
free -t --mega| grep "Total:" | awk '{print "- Espacio usado total ocupado de la memoria: " $3" MB"}'

uptime | awk '{print "Tiempo en linea: " $5}' | cut -d "," -f1
echo "Cantidad de archivos en /home : `ls -lR $HOME |wc -c`"
ls -lR $HOME |awk ' {suma += $5 } END {print "El tamaño total de los archivos en /home es: " suma/1024 " MB" }'

top -bn1 |grep "%Cpu"| awk '{print "CPU: \n- Ocupado por usuario " $2 " % "   "\n- Espera "  $10 " % "   "\n- Sistema "  $4 " % "}'



