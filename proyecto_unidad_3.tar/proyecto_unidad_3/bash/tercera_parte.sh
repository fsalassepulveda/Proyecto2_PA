#!/bin/bash
echo -e "\n--------------------------------------------------------------------------"

OPCION=$1

if [ $OPCION == "A" ];then
    clear
    echo -e "ARCHIVOS MODIFICADOS EN LAS ULTIMAS 24 HORAS: "
    find . -mtime 0 -printf '%T+\t%s\t%p\n' 2>/dev/null | sort -r | more |awk '{ print $1 " ---------------- " $3 }'
    echo -e "\n--------------------------------------------------------------------"

elif [ $OPCION == "B" ];then
    echo -e "\n CONEXIONES REALIZADAS DENTRO DE LAS ULTIMAS 24 HRS : "
    ls -lhR $HOME| grep ^d | awk 'sum +=1 {print "-" $9} END{print "Total ficheros: " sum }'
    echo -e "\n--------------------------------------------------------------------"

elif [ $OPCION == "C" ];then
    echo "EJECUTAR  UN SCRIPT PERIODICAMENTE  :"
    
fi
