#!/bin/bash
ls -lR $HOME |awk ' {suma += $5 } END {print "El tamaño total de los archivos en /home es: " suma/1024 " MB" }'