#!/bin/bash

echo "ADIOS"
