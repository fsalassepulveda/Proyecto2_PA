#!/bin/bash

clear
echo "MENU USUARIOS"
#Implementar menu para elegir qué hacer?
awk 'BEGIN { print "Usuarios reales:  "} $3 >= 1000 { print "	- UID del usuario "$1" :" $3   | "sort -r"}' FS=":" /etc/passwd 
echo "Escriba inicial de usuario que desea encontrar:"
VARIABLE= $1
echo $VARIABLE
