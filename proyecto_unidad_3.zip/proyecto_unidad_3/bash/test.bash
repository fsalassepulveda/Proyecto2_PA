#!/bin/bash
#INICIO


clear
echo -e "BIENVENIDE $USER
-----------------------
`date +"%A %d/%m/%Y %H":"%M"`\n"

echo -e "INFORMACION DEL SISTEMA:
------------------------"
echo "Nombre de la maquina (Host): `uname -n` " 
echo -e "Sistema operativo: `uname -o`"
echo "MEMORIA:"
free --mega| grep "Memoria: " | awk '{print "	Espacio libre de la memoria: " $3 " MB"}'
free --mega | grep "Swap:" | awk '{print "	Espacio libre de la memoria virtual: " $3 " MB"}'
free -t --mega| grep "Total:" | awk '{print "	Espacio usado  total ocupado de la memoria: " $3" MB\n"}'
uptime |awk '{print "Tiempo en linea: "$3 }' |cut -d "," -f1

echo "Cantidad de archivos en /home : `ls -l $HOME |wc -c`"
ls -l $HOME |awk ' {suma += $5 } END {print "El tamaño total de los archivos en /home es: " suma/1024 " MB" }'
top -bn1 |grep "%Cpu"| awk '{print "%CPU: \n    Ocupado por usuario: " $2 "%\n    Ocupado por sistema: " $10 "%\n    Ocupado en espera: " $4 "%" }'


